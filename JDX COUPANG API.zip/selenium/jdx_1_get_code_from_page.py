from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import json

#Open Chrome
options = webdriver.ChromeOptions() 
options.add_experimental_option("excludeSwitches", ["enable-logging"])
driver = webdriver.Chrome(options=options, executable_path="C:/jdxcode/selenium/chromedriver.exe")
# driver = webdriver.Chrome("C:/selenium/chromedriver.exe")

# get all code from jdx (if num == LAST PAGE + 1: break)
all_code = []

# change page_num (should be <= 15) (last page + 1)
endpage_num = 7

num = 1
while True:
    if num == endpage_num: break
    driver.get(f"https://www.jdx.co.kr/productlist?number=40&season%5B0%5D=W&recent=a&page={num}")
    time.sleep(2)
    elems = driver.find_elements_by_css_selector(".bt-tp-nor.light.wishadd")
    for elem in elems:
        all_code.append(elem.get_attribute("data-type1"))
    num += 1

#save all_code to py
with open("C:/jdxcode/selenium/jdx_1-1_all_code.py", 'w') as f:
    json.dump(all_code, f)

driver.close()




##########################################################################################################

# from selenium import webdriver
# from selenium.webdriver.common.keys import Keys
# import time
# import json




#open jdx_2_all_code.py as all_code
with open("C:/jdxcode/selenium/jdx_1-1_all_code.py", 'r') as f:
   all_code = json.load(f)

#get info from code(name, ori_price, sale_price, photo_front, photo_detail)
start = 0
end = 30
dic_code = {}
code = ""

while code != all_code[-1]:
    #Open Chrome
    driver = webdriver.Chrome(options=options, executable_path="C:/jdxcode/selenium/chromedriver.exe")

    try:
        for code in all_code[start:end]:
            driver.get(f"http://jdx.co.kr/detail?productcode={code}")
            time.sleep(0.5)
            photo_front = []
            i = 1 
            name = driver.find_element_by_xpath("/html/body/section/div[1]/div[2]/div[2]/h1")
            name = name.text
            name = "6층_JDX_" + name[5:-13] + f"_{code}_평촌점"
            ori_price = driver.find_element_by_xpath("/html/body/section/div[1]/div[2]/ul[1]/li[1]/p")
            ori_price = ori_price.text
            ori_price = ori_price.replace(",", "")
            ori_price = ori_price[:-1]
            sale_price = driver.find_element_by_xpath("/html/body/section/div[1]/div[2]/ul[1]/li[2]/p")
            sale_price = sale_price.text
            sale_price = sale_price.replace(",", "")
            sale_price = sale_price[:-1]
            photo_detail = driver.find_element_by_xpath("/html/body/section/div[4]/div/div/center/img[2]")
            photo_detail = photo_detail.get_attribute("src")
            while True:
                try:
                    front = driver.find_element_by_xpath(f"/html/body/section/div[1]/div[1]/div/div[1]/div[{i}]/img")
                    front = front.get_attribute("src")
                    photo_front.append(front)
                    i += 1
                except:
                    break

            name = {'name': name}
            ori_price = {'ori_price': ori_price}
            sale_price = {'sale_price': sale_price}
            photo_front = {'photo_front': photo_front}
            photo_detail = {'photo_detail': photo_detail}
            
            code_info = [name, ori_price, sale_price, photo_front, photo_detail]
            dic_code[code] = code_info

        start += 30
        end += 30
        driver.close()
    
    except:
        break


with open("C:/jdxcode/selenium/jdx_1-2_info.py", 'w', encoding='utf-8') as f:
    json.dump(dic_code, f, ensure_ascii=False)
    

# # assert "Python" in driver.title
# # elem = driver.find_element_by_name("q")
# # elem.clear()
# # elem.send_keys("pycon")
# # elem.send_keys(Keys.RETURN)
# # assert "No results found." not in driver.page_source
# # driver.close()
