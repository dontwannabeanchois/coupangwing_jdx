import json
with open("C:/jdxcode/selenium/jdx_2-1_result.py", "r", encoding="utf-8") as f:
	all_data = json.load(f)

all_category = []
for data in all_data:
    all_category.append(all_data[data]["displayCategoryCode"])

sort_of_category = list(set(all_category))
print(sort_of_category)
print(len(sort_of_category))