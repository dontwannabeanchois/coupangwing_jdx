from selenium import webdriver
from PIL import Image
from io import BytesIO
import time
# ActionChains 를 사용하기 위해서.
from selenium.webdriver import ActionChains


stock = ["코스피", "삼성전자", "인텔리안테크"]
for name in stock:
    driver = webdriver.Chrome(r"C:\python_test\pythonscreenshot\chromedriver.exe")
    driver.get(f"https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query={name}")

    #ERROR
    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    driver = webdriver.Chrome('chromedriver.exe', options=options)

    # id가 something 인 element 를 찾음
    some_tag = driver.find_element_by_css_selector(".api_cs_wrap")

    # somthing element 까지 스크롤
    action = ActionChains(driver)
    action.move_to_element(some_tag).perform()

    # now that we have the preliminary stuff out of the way time to get that image :D
    element = driver.find_element_by_css_selector(".api_cs_wrap") # find part of the page you want image of

    chart = ["데이", "일봉", "주봉"]
    for chart_name in chart:
        if chart_name == "데이":
            driver.find_element_by_xpath("//*[@id='_cs_root']/div[2]/div[1]/div[1]/ul/li[1]/a").click()
        elif chart_name == "일봉":
            driver.find_element_by_xpath("//*[@id='_cs_root']/div[2]/div[1]/div[1]/ul/li[6]/a").click()
        elif chart_name == "주봉":
            driver.find_element_by_xpath("//*[@id='_cs_root']/div[2]/div[1]/div[1]/ul/li[7]/a").click()

        location = element.location_once_scrolled_into_view
        size = element.size
        png = driver.get_screenshot_as_png() # saves screenshot of entire page

        im = Image.open(BytesIO(png)) # uses PIL library to open image in memory

        left = location['x'] -5
        top = location['y'] -10
        right = left + size['width'] -310
        bottom = location['y'] + size['height'] -150

        im = im.crop((left, top, right, bottom)) # defines crop points
        im.save(f"C:\\Users\\bel03\\OneDrive\\바탕 화면\\stock\\{name}_{chart_name}.png") # saves new cropped image

    driver.quit()

